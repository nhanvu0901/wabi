/* @ds-bundle: {"format":4,"namespace":"Ds8senecaDesignSystem_e04158","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"GlassCard","sourcePath":"components/core/GlassCard.jsx"},{"name":"SectionHeading","sourcePath":"components/core/SectionHeading.jsx"},{"name":"ShimmerButton","sourcePath":"components/core/ShimmerButton.jsx"},{"name":"ReviewCard","sourcePath":"components/data/ReviewCard.jsx"},{"name":"ServiceCard","sourcePath":"components/data/ServiceCard.jsx"},{"name":"StatTicker","sourcePath":"components/data/StatTicker.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"baa03d04cf7e","components/core/Button.jsx":"893f481ae1d3","components/core/GlassCard.jsx":"b6e81d999c40","components/core/SectionHeading.jsx":"5175ac4d2dd9","components/core/ShimmerButton.jsx":"b5b2c46a02e1","components/data/ReviewCard.jsx":"58aa3298f158","components/data/ServiceCard.jsx":"e8733a44262a","components/data/StatTicker.jsx":"cff6b0b7fba8","components/forms/Checkbox.jsx":"7d0a26e66c34","components/forms/Input.jsx":"6566897571a6","components/forms/Textarea.jsx":"b2715fecdc0b","ui_kits/website/ContactScreen.jsx":"c9ecb9dd923c","ui_kits/website/HomeScreen.jsx":"498ae3b7d483","ui_kits/website/PortfolioScreen.jsx":"7a79dc3fecdd","ui_kits/website/Shell.jsx":"600ef727a033","ui_kits/website/icons.jsx":"68fffcd48146"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.Ds8senecaDesignSystem_e04158 = window.Ds8senecaDesignSystem_e04158 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
/**
 * 8seneca Badge — small pill / eyebrow label. `eyebrow` renders the uppercase
 * tracked label with a short gradient rule (as used above hero/section headings);
 * `solid`/`soft`/`outline` render compact tag chips.
 */
function Badge({
  children,
  variant = 'soft',
  className = '',
  style = {}
}) {
  if (variant === 'eyebrow') {
    return /*#__PURE__*/React.createElement("span", {
      className: className,
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 12,
        fontFamily: 'var(--font-body)',
        fontSize: 11,
        fontWeight: 500,
        textTransform: 'uppercase',
        letterSpacing: 'var(--tracking-eyebrow)',
        color: 'var(--text-muted)',
        ...style
      }
    }, /*#__PURE__*/React.createElement("span", {
      "aria-hidden": true,
      style: {
        width: 28,
        height: 1,
        background: 'var(--brand-gradient)',
        flexShrink: 0
      }
    }), children);
  }
  const variants = {
    solid: {
      backgroundImage: 'var(--brand-gradient)',
      color: '#fff',
      border: '1px solid transparent'
    },
    soft: {
      background: 'var(--surface-glass)',
      color: '#fff',
      border: '1px solid var(--border-glass)'
    },
    outline: {
      background: 'transparent',
      color: 'var(--brand-blue)',
      border: '1px solid rgba(86,117,254,0.5)'
    }
  };
  return /*#__PURE__*/React.createElement("span", {
    className: className,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      fontFamily: 'var(--font-body)',
      fontSize: 12,
      fontWeight: 600,
      lineHeight: 1,
      padding: '5px 12px',
      borderRadius: 'var(--radius-pill)',
      whiteSpace: 'nowrap',
      ...(variants[variant] || variants.soft),
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * 8seneca Button — the site's primary action control.
 * - primary: fills with the signature blue→red brand gradient
 * - secondary: dark glass (white/5) with a light border, brightens on hover
 * - ghost: transparent, subtle white wash on hover
 * - link: inline gradient/blue text link with optional trailing arrow
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  iconLeft = null,
  iconRight = null,
  type = 'button',
  onClick,
  className = '',
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '8px 16px',
      fontSize: 14,
      radius: 'var(--radius-xs)'
    },
    md: {
      padding: '10px 24px',
      fontSize: 15,
      radius: 'var(--radius-s)'
    },
    lg: {
      padding: '16px 36px',
      fontSize: 16,
      radius: 'var(--radius-s)'
    }
  };
  const s = sizes[size] || sizes.md;
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    fontFamily: 'var(--font-body)',
    fontWeight: 600,
    fontSize: s.fontSize,
    lineHeight: 1,
    padding: s.padding,
    borderRadius: s.radius,
    letterSpacing: '0.01em',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    border: '1px solid transparent',
    transition: 'all var(--dur-med) var(--ease-out)',
    whiteSpace: 'nowrap',
    ...style
  };
  const variants = {
    primary: {
      backgroundImage: 'var(--brand-gradient)',
      color: '#fff',
      boxShadow: 'var(--glow-blue)'
    },
    secondary: {
      background: 'var(--surface-glass)',
      color: '#fff',
      borderColor: 'var(--border-glass-strong)'
    },
    ghost: {
      background: 'transparent',
      color: 'rgba(255,255,255,0.9)'
    },
    link: {
      background: 'transparent',
      color: 'var(--brand-blue)',
      padding: 0,
      border: 'none',
      borderRadius: 0
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    className: className,
    style: {
      ...base,
      ...(variants[variant] || variants.primary)
    },
    onMouseEnter: e => {
      if (disabled) return;
      if (variant === 'secondary') e.currentTarget.style.background = 'var(--surface-glass-hover)';
      if (variant === 'ghost') e.currentTarget.style.background = 'rgba(255,255,255,0.06)';
      if (variant === 'primary') e.currentTarget.style.boxShadow = 'var(--glow-blue-strong)';
      if (variant === 'link') e.currentTarget.style.color = 'var(--primary-400)';
    },
    onMouseLeave: e => {
      if (variant === 'secondary') e.currentTarget.style.background = 'var(--surface-glass)';
      if (variant === 'ghost') e.currentTarget.style.background = 'transparent';
      if (variant === 'primary') e.currentTarget.style.boxShadow = 'var(--glow-blue)';
      if (variant === 'link') e.currentTarget.style.color = 'var(--brand-blue)';
    }
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/GlassCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * 8seneca GlassCard — the site's ubiquitous surface: a frosted white/5 panel with a
 * hairline border, offset shadow and rounded corners. Lifts and brightens on hover
 * when `interactive`. Wraps any content (bento tiles, portfolio cards, forms).
 */
function GlassCard({
  children,
  interactive = false,
  radius = 'var(--radius-l)',
  padding = 24,
  className = '',
  style = {},
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => interactive && setHover(true),
    onMouseLeave: () => interactive && setHover(false),
    className: className,
    style: {
      position: 'relative',
      overflow: 'hidden',
      borderRadius: radius,
      padding,
      background: hover ? 'var(--surface-glass-hover)' : 'var(--surface-glass)',
      border: '1px solid',
      borderColor: hover ? 'rgba(86,117,254,0.40)' : 'var(--border-glass)',
      boxShadow: 'var(--shadow-card)',
      backdropFilter: 'var(--blur-glass)',
      WebkitBackdropFilter: 'var(--blur-glass)',
      transition: 'transform var(--dur-med) var(--ease-out), border-color var(--dur-med) var(--ease-out), background var(--dur-med) var(--ease-out)',
      transform: hover ? 'translateY(-4px)' : 'none',
      cursor: interactive ? 'pointer' : 'default',
      color: 'var(--text-body)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { GlassCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/GlassCard.jsx", error: String((e && e.message) || e) }); }

// components/core/SectionHeading.jsx
try { (() => {
/**
 * 8seneca SectionHeading — centered (or left) section title with an optional eyebrow
 * and a gradient-clipped accent word. Matches the site pattern where the last word (or
 * an explicit accent) is rendered in the blue→red gradient, often italic.
 */
function SectionHeading({
  eyebrow = '',
  title = '',
  accent = '',
  align = 'center',
  size = 'lg',
  className = '',
  style = {}
}) {
  const sizes = {
    md: 'clamp(1.75rem,4vw,2.6rem)',
    lg: 'clamp(2rem,5vw,3.4rem)',
    xl: 'clamp(2.4rem,6vw,4rem)'
  };
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: align === 'center' ? 'center' : 'flex-start',
      textAlign: align,
      gap: 16,
      ...style
    }
  }, eyebrow ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 12,
      fontFamily: 'var(--font-body)',
      fontSize: 11,
      fontWeight: 500,
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-eyebrow)',
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    style: {
      width: 28,
      height: 1,
      background: 'var(--brand-gradient)'
    }
  }), eyebrow) : null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-body)',
      fontWeight: 700,
      fontSize: sizes[size] || sizes.lg,
      lineHeight: 1.1,
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--text-strong)',
      textWrap: 'balance',
      margin: 0
    }
  }, title, ' ', accent ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontStyle: 'italic',
      backgroundImage: 'var(--brand-gradient)',
      WebkitBackgroundClip: 'text',
      backgroundClip: 'text',
      color: 'transparent',
      WebkitTextFillColor: 'transparent',
      paddingInlineEnd: '0.12em'
    }
  }, accent) : null));
}
Object.assign(__ds_scope, { SectionHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SectionHeading.jsx", error: String((e && e.message) || e) }); }

// components/core/ShimmerButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * 8seneca ShimmerButton — the header/hero CTA with a rotating light spark sweeping
 * the border. Reproduces the site's Magic UI shimmer button in plain CSS.
 */
function ShimmerButton({
  children,
  background = 'var(--brand-gradient)',
  shimmerColor = '#ffffff',
  borderRadius = '100px',
  duration = '3s',
  onClick,
  className = '',
  style = {},
  ...rest
}) {
  const id = React.useId().replace(/:/g, '');
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, `
        @keyframes sb-spin-${id}{from{transform:translateZ(0) rotate(0)}to{transform:translateZ(0) rotate(360deg)}}
        .sb-${id}:active{transform:translateY(1px)}
      `), /*#__PURE__*/React.createElement("button", _extends({
    onClick: onClick,
    className: `sb-${id} ${className}`,
    style: {
      position: 'relative',
      zIndex: 0,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      overflow: 'hidden',
      cursor: 'pointer',
      padding: '14px 36px',
      borderRadius: borderRadius,
      border: '1px solid rgba(255,255,255,0.10)',
      color: '#fff',
      fontFamily: 'var(--font-body)',
      fontWeight: 600,
      fontSize: 15,
      letterSpacing: '0.02em',
      whiteSpace: 'nowrap',
      background: background,
      transition: 'transform var(--dur-med) var(--ease-out)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: -30,
      overflow: 'hidden',
      borderRadius: borderRadius,
      filter: 'blur(2px)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: '-150%',
      animation: `sb-spin-${id} ${duration} linear infinite`,
      background: `conic-gradient(from 225deg, transparent 0, ${shimmerColor} 90deg, transparent 90deg)`
    }
  })), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    style: {
      position: 'absolute',
      inset: '0.05em',
      zIndex: -20,
      borderRadius: borderRadius,
      background: background
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: borderRadius,
      boxShadow: 'inset 0 -8px 10px #ffffff1f'
    }
  }), children));
}
Object.assign(__ds_scope, { ShimmerButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ShimmerButton.jsx", error: String((e && e.message) || e) }); }

// components/data/ReviewCard.jsx
try { (() => {
/**
 * 8seneca ReviewCard — client testimonial card used in the trust marquee. Glass panel
 * with a source badge (trustpilot / clutch / itviec), star row, quote, and author line.
 */
function ReviewCard({
  quote = '',
  author = '',
  role = '',
  source = 'trustpilot',
  rating = 5,
  className = '',
  style = {}
}) {
  const sourceColor = {
    trustpilot: '#00b67a',
    clutch: '#ff3d2e',
    itviec: '#d73b3e'
  }[source] || 'var(--brand-blue)';
  const sourceLabel = {
    trustpilot: 'Trustpilot',
    clutch: 'Clutch',
    itviec: 'ITviec'
  }[source] || source;
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      width: 340,
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 14,
      padding: 24,
      borderRadius: 'var(--radius-m)',
      background: 'var(--surface-glass)',
      border: '1px solid var(--border-glass)',
      backdropFilter: 'var(--blur-glass)',
      WebkitBackdropFilter: 'var(--blur-glass)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 2
    }
  }, Array.from({
    length: 5
  }).map((_, i) => /*#__PURE__*/React.createElement("svg", {
    key: i,
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: i < rating ? sourceColor : 'rgba(255,255,255,0.15)'
  }, /*#__PURE__*/React.createElement("polygon", {
    points: "12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
  })))), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 11,
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: '0.08em',
      color: sourceColor
    }
  }, sourceLabel)), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      lineHeight: 1.6,
      color: 'var(--text-body)',
      margin: 0
    }
  }, "\u201C", quote, "\u201D"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      fontWeight: 600,
      color: '#fff'
    }
  }, author), role ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 12,
      color: 'var(--text-faint)'
    }
  }, role) : null));
}
Object.assign(__ds_scope, { ReviewCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ReviewCard.jsx", error: String((e && e.message) || e) }); }

// components/data/ServiceCard.jsx
try { (() => {
/**
 * 8seneca ServiceCard — bento service tile. A glass panel with a title, description,
 * a "Get started" gradient link, and an oversized watermark icon bleeding off the
 * bottom-right corner that warms to blue on hover. `icon` is any node (e.g. a Lucide
 * icon element); it is cloned large + faint as the background accent.
 */
function ServiceCard({
  title = '',
  description = '',
  icon = null,
  cta = 'Get started',
  href = '#',
  wide = false,
  className = '',
  style = {}
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: href,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    className: className,
    style: {
      position: 'relative',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      minHeight: 208,
      overflow: 'hidden',
      borderRadius: 'var(--radius-l)',
      padding: 24,
      textDecoration: 'none',
      background: hover ? 'var(--surface-glass-hover)' : 'var(--surface-glass)',
      border: '1px solid',
      borderColor: hover ? 'rgba(86,117,254,0.40)' : 'var(--border-glass)',
      backdropFilter: 'var(--blur-glass)',
      WebkitBackdropFilter: 'var(--blur-glass)',
      transform: hover ? 'translateY(-4px)' : 'none',
      transition: 'all var(--dur-med) var(--ease-out)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    style: {
      position: 'absolute',
      bottom: wide ? -40 : -32,
      right: wide ? -24 : -20,
      width: wide ? 256 : 176,
      height: wide ? 256 : 176,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: hover ? 'rgba(86,117,254,0.20)' : 'rgba(255,255,255,0.05)',
      transform: hover ? 'scale(1.1)' : 'scale(1)',
      transition: 'all var(--dur-slow) var(--ease-out)',
      pointerEvents: 'none'
    }
  }, icon && React.isValidElement(icon) ? React.cloneElement(icon, {
    size: wide ? 220 : 150,
    strokeWidth: 1.5,
    width: wide ? 220 : 150,
    height: wide ? 220 : 150
  }) : icon), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 20,
      color: 'var(--text-strong)',
      margin: 0
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      maxWidth: '85%',
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      color: 'var(--text-muted)',
      margin: 0,
      lineHeight: 1.5
    }
  }, description)), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      marginTop: 16,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      fontWeight: 600,
      color: 'var(--brand-blue)'
    }
  }, cta, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      transform: hover ? 'translateX(4px)' : 'none',
      transition: 'transform var(--dur-med) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("line", {
    x1: "5",
    y1: "12",
    x2: "19",
    y2: "12"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "12 5 19 12 12 19"
  }))));
}
Object.assign(__ds_scope, { ServiceCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ServiceCard.jsx", error: String((e && e.message) || e) }); }

// components/data/StatTicker.jsx
try { (() => {
/**
 * 8seneca StatTicker — a big display number that counts up on mount, with a
 * gradient "+" suffix and a muted label beneath. Used in the trust strip
 * (engineers, domains, projects, EU-managed).
 */
function StatTicker({
  value = 0,
  suffix = '+',
  text = '',
  label = '',
  duration = 1500,
  className = '',
  style = {}
}) {
  const isNumeric = text === '' || text == null;
  const [display, setDisplay] = React.useState(isNumeric ? 0 : text);
  React.useEffect(() => {
    if (!isNumeric) return;
    let raf;
    const start = performance.now();
    const tick = now => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(Math.round(eased * value));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, duration, isNumeric]);
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 16,
      textAlign: 'center',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 'clamp(2.6rem,6vw,4.2rem)',
      lineHeight: 0.9,
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--text-strong)'
    }
  }, isNumeric ? display : text, isNumeric && suffix ? /*#__PURE__*/React.createElement("span", {
    style: {
      backgroundImage: 'var(--brand-gradient)',
      WebkitBackgroundClip: 'text',
      backgroundClip: 'text',
      color: 'transparent',
      WebkitTextFillColor: 'transparent'
    }
  }, suffix) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 15,
      color: 'var(--text-muted)'
    }
  }, label));
}
Object.assign(__ds_scope, { StatTicker });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatTicker.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
/**
 * 8seneca Checkbox — custom control on dark glass. Checked state fills brand blue
 * with a white check; larger tap target than the native box.
 */
function Checkbox({
  checked = false,
  onChange,
  children,
  required = false,
  id,
  className = '',
  style = {}
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: className,
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 12,
      cursor: 'pointer',
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      color: 'var(--text-muted)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    onClick: () => onChange && onChange(!checked),
    style: {
      marginTop: 1,
      flexShrink: 0,
      width: 24,
      height: 24,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 6,
      border: '1px solid',
      borderColor: checked ? 'var(--brand-blue)' : 'var(--border-glass-strong)',
      background: checked ? 'var(--brand-blue)' : 'var(--surface-glass)',
      transition: 'all var(--dur-fast) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("input", {
    id: id,
    type: "checkbox",
    checked: checked,
    required: required,
    onChange: e => onChange && onChange(e.target.checked),
    style: {
      position: 'absolute',
      width: 1,
      height: 1,
      opacity: 0,
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "#fff",
    strokeWidth: "3",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      transform: checked ? 'scale(1)' : 'scale(0)',
      transition: 'transform var(--dur-fast) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "20 6 9 17 4 12"
  }))), children ? /*#__PURE__*/React.createElement("span", {
    style: {
      lineHeight: 1.4
    }
  }, children) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
/**
 * 8seneca Input — text field for the dark glass surfaces. A bordered, rounded
 * container with an optional label; focus lights the border blue.
 */
function Input({
  label = '',
  placeholder = '',
  type = 'text',
  value,
  defaultValue,
  onChange,
  required = false,
  disabled = false,
  id,
  className = '',
  style = {}
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", {
    className: className,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 13,
      fontWeight: 500,
      color: 'var(--text-muted)'
    }
  }, label, required ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--brand-red)'
    }
  }, " *") : null) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      padding: '12px 16px',
      borderRadius: 'var(--radius-xs)',
      background: 'var(--surface-glass)',
      border: '1px solid',
      borderColor: focus ? 'rgba(86,117,254,0.6)' : 'var(--border-glass)',
      boxShadow: focus ? '0 0 0 3px rgba(86,117,254,0.15)' : 'none',
      transition: 'border-color var(--dur-med) var(--ease-out), box-shadow var(--dur-med) var(--ease-out)',
      opacity: disabled ? 0.5 : 1
    }
  }, /*#__PURE__*/React.createElement("input", {
    id: id,
    type: type,
    value: value,
    defaultValue: defaultValue,
    placeholder: placeholder,
    required: required,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      outline: 'none',
      border: 'none',
      background: 'transparent',
      color: '#fff',
      fontFamily: 'var(--font-body)',
      fontSize: 15
    }
  })));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
/** 8seneca Textarea — multi-line variant of Input for message fields. */
function Textarea({
  label = '',
  placeholder = '',
  value,
  defaultValue,
  onChange,
  required = false,
  disabled = false,
  rows = 4,
  id,
  className = '',
  style = {}
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", {
    className: className,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 13,
      fontWeight: 500,
      color: 'var(--text-muted)'
    }
  }, label, required ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--brand-red)'
    }
  }, " *") : null) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 16px',
      borderRadius: 'var(--radius-xs)',
      background: 'var(--surface-glass)',
      border: '1px solid',
      borderColor: focus ? 'rgba(86,117,254,0.6)' : 'var(--border-glass)',
      boxShadow: focus ? '0 0 0 3px rgba(86,117,254,0.15)' : 'none',
      transition: 'border-color var(--dur-med) var(--ease-out), box-shadow var(--dur-med) var(--ease-out)',
      opacity: disabled ? 0.5 : 1
    }
  }, /*#__PURE__*/React.createElement("textarea", {
    id: id,
    rows: rows,
    value: value,
    defaultValue: defaultValue,
    placeholder: placeholder,
    required: required,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      resize: 'vertical',
      outline: 'none',
      border: 'none',
      background: 'transparent',
      color: '#fff',
      fontFamily: 'var(--font-body)',
      fontSize: 15,
      lineHeight: 1.5
    }
  })));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ContactScreen.jsx
try { (() => {
// Contact: booking form (Direction C). Left = pitch + info, right = glass form with
// name/email/company, message, consent checkbox, and a Book-a-call submit → success state.
const {
  Input,
  Textarea,
  Checkbox,
  ShimmerButton,
  Badge,
  GlassCard,
  SectionHeading
} = window.Ds8senecaDesignSystem_e04158;
function ContactScreen() {
  const [sent, setSent] = React.useState(false);
  const [agree, setAgree] = React.useState(false);
  const {
    Check,
    MapPin
  } = window.Icons;
  return /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 1120,
      margin: '0 auto',
      padding: '56px 32px 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1.1fr',
      gap: 56,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Contact",
    title: "Book a",
    accent: "call.",
    align: "left",
    size: "lg"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-body)',
      fontSize: 17,
      lineHeight: 1.65,
      marginTop: 20,
      maxWidth: 420
    }
  }, "Tell us what you're building. We'll line up the right engineers and a transparent plan \u2014 usually within one business day."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 32,
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, [['30-min intro', 'Google Meet, at a time that suits you'], ['No obligation', 'A plan and a quote, not a hard sell'], ['EU + VN', 'Timezone overlap that actually works']].map(([t, d]) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flexShrink: 0,
      width: 32,
      height: 32,
      borderRadius: 8,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundImage: 'var(--brand-gradient)',
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement(Check, {
    size: 16
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      color: '#fff',
      fontWeight: 600,
      fontSize: 15
    }
  }, t), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 14
    }
  }, d)))))), /*#__PURE__*/React.createElement(GlassCard, null, sent ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '48px 12px',
      textAlign: 'center',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 64,
      height: 64,
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundImage: 'var(--brand-gradient)',
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement(Check, {
    size: 30
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 24,
      color: '#fff',
      margin: 0
    }
  }, "Request sent"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-muted)',
      maxWidth: 320,
      margin: 0
    }
  }, "We've emailed a calendar invite. Talk soon \u2014 the 8seneca team."), /*#__PURE__*/React.createElement("button", {
    onClick: () => setSent(false),
    style: {
      marginTop: 8,
      background: 'none',
      border: 'none',
      color: 'var(--brand-blue)',
      fontWeight: 600,
      cursor: 'pointer',
      fontFamily: 'var(--font-body)',
      fontSize: 14
    }
  }, "\u2190 Send another")) : /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
    },
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Full name",
    placeholder: "Jane Doe",
    required: true
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Work email",
    type: "email",
    placeholder: "you@company.com",
    required: true
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Company",
    placeholder: "Acme Inc.",
    style: {
      gridColumn: '1 / -1'
    }
  }), /*#__PURE__*/React.createElement(Textarea, {
    label: "What are you building?",
    rows: 4,
    placeholder: "A few sentences about the team or project\u2026",
    style: {
      gridColumn: '1 / -1'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '1 / -1'
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    checked: agree,
    onChange: setAgree,
    required: true
  }, "I agree to the processing of my data per the privacy policy.")), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '1 / -1',
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(ShimmerButton, {
    type: "submit",
    style: {
      width: '100%',
      justifyContent: 'center'
    }
  }, "Book a call"))))));
}
function BlogScreen() {
  const {
    SectionHeading,
    GlassCard,
    Badge
  } = window.Ds8senecaDesignSystem_e04158;
  const posts = [{
    t: 'What "Pure Play" really means for your roadmap',
    tag: 'Strategy',
    big: true
  }, {
    t: 'Timezone overlap: the EU + Vietnam playbook',
    tag: 'Teams'
  }, {
    t: 'Milestone payments that keep everyone honest',
    tag: 'Process'
  }, {
    t: 'Shipping secure code by default',
    tag: 'Security'
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 1120,
      margin: '0 auto',
      padding: '56px 32px 32px'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Blog",
    title: "Notes on",
    accent: "building teams"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(2,1fr)',
      gap: 16,
      marginTop: 44
    }
  }, posts.map(p => /*#__PURE__*/React.createElement(GlassCard, {
    key: p.t,
    interactive: true,
    radius: "var(--radius-m)",
    style: {
      gridColumn: p.big ? '1 / -1' : 'span 1',
      minHeight: p.big ? 200 : 150,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: "outline"
  }, p.tag), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: p.big ? 28 : 20,
      fontWeight: 600,
      color: '#fff',
      margin: 0,
      maxWidth: 520
    }
  }, p.t)))));
}
Object.assign(window, {
  ContactScreen,
  BlogScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ContactScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomeScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Homepage: hero (bento), trust strip, services bento, global-talent, final CTA.
// Composes the design-system primitives against the aurora backdrop.
const {
  Badge,
  ShimmerButton,
  Button,
  StatTicker,
  ServiceCard,
  ReviewCard,
  SectionHeading,
  GlassCard
} = window.Ds8senecaDesignSystem_e04158;
const MODELS = [{
  title: 'Talent Hiring',
  desc: 'The right talent, ready to scale.'
}, {
  title: 'Custom Projects',
  desc: 'Solutions built for your vision.'
}, {
  title: 'Team Hiring',
  desc: 'Strength in collaboration.'
}];
const SERVICES = [{
  key: 'Software Development',
  desc: 'High-performance code, built for scale.',
  icon: 'Code',
  wide: true
}, {
  key: 'Cybersecurity',
  desc: 'Adaptive architecture. Uncompromising protection.',
  icon: 'Shield'
}, {
  key: 'IT Outsourcing',
  desc: 'Dedicated teams. Seamless execution.',
  icon: 'Users'
}, {
  key: 'Design',
  desc: 'Interfaces that inspire and connect.',
  icon: 'Pen'
}, {
  key: 'Marketing',
  desc: "Visibility that's precise and impactful.",
  icon: 'Megaphone'
}];
const REVIEWS = [{
  source: 'clutch',
  quote: 'Senior output on our timezone, at a sustainable cost. They just ship.',
  author: 'Head of Engineering',
  role: 'Fintech scale-up'
}, {
  source: 'trustpilot',
  quote: 'European management made the whole engagement transparent and easy.',
  author: 'CTO',
  role: 'SaaS company'
}, {
  source: 'itviec',
  quote: 'A genuinely strong engineering bench. Onboarding was two days.',
  author: 'VP Product',
  role: 'E-commerce'
}];
function Section({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      padding: '64px 32px',
      ...style
    }
  }, children);
}
function HomeScreen({
  setRoute
}) {
  const {
    Arrow
  } = window.Icons;
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Section, {
    style: {
      paddingTop: 40,
      paddingBottom: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.35fr 1fr',
      gap: 56,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Badge, {
    variant: "eyebrow"
  }, "Pure Play \xB7 B2B IT Outsourcing"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-body)',
      fontWeight: 700,
      fontSize: 'clamp(2.4rem,4.5vw,3.8rem)',
      lineHeight: 1.05,
      letterSpacing: '-0.02em',
      color: '#fff',
      margin: '22px 0 0'
    }
  }, "Scale your engineering team,", /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontStyle: 'italic',
      marginTop: 4,
      backgroundImage: 'var(--brand-gradient)',
      WebkitBackgroundClip: 'text',
      backgroundClip: 'text',
      WebkitTextFillColor: 'transparent',
      paddingBottom: '0.12em'
    }
  }, "without the overhead.")), /*#__PURE__*/React.createElement("p", {
    style: {
      maxWidth: 520,
      color: 'var(--text-body)',
      fontSize: 19,
      lineHeight: 1.6,
      marginTop: 22
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      color: '#fff'
    }
  }, "European"), " management, elite ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: '#fff'
    }
  }, "Vietnamese"), " talent. ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: '#fff'
    }
  }, "One focus:"), " B2B IT outsourcing that ", /*#__PURE__*/React.createElement("i", {
    style: {
      textDecoration: 'underline',
      textDecorationColor: 'var(--brand-blue)',
      textUnderlineOffset: 4
    }
  }, "actually"), " ships."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      alignItems: 'center',
      marginTop: 34
    }
  }, /*#__PURE__*/React.createElement(ShimmerButton, {
    onClick: () => setRoute('Contact')
  }, "Book a call"), /*#__PURE__*/React.createElement(Button, {
    variant: "link",
    iconRight: /*#__PURE__*/React.createElement(Arrow, {
      size: 18
    }),
    onClick: () => setRoute('Portfolio')
  }, "View our work"))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border-glass)'
    }
  }, MODELS.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: m.title,
    onClick: () => setRoute('Contact'),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 20,
      padding: '22px 0',
      borderBottom: '1px solid var(--border-glass)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      fontWeight: 600,
      letterSpacing: '0.1em',
      color: 'var(--brand-blue)'
    }
  }, "0", i + 1), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 19,
      fontWeight: 600,
      color: '#fff'
    }
  }, m.title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: 'var(--text-muted)',
      marginTop: 3
    }
  }, m.desc)), /*#__PURE__*/React.createElement(Arrow, {
    size: 18,
    style: {
      color: 'var(--text-faint)'
    }
  })))))), /*#__PURE__*/React.createElement(Section, {
    style: {
      paddingTop: 32,
      paddingBottom: 32
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    title: "Trusted delivery,",
    accent: "by the numbers"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 40,
      marginTop: 48
    }
  }, /*#__PURE__*/React.createElement(StatTicker, {
    value: 24,
    label: "Projects delivered"
  }), /*#__PURE__*/React.createElement(StatTicker, {
    value: 7,
    label: "Industry domains"
  }), /*#__PURE__*/React.createElement(StatTicker, {
    value: 5,
    label: "Core services"
  }), /*#__PURE__*/React.createElement(StatTicker, {
    text: "EU",
    suffix: "",
    label: "European-managed"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      justifyContent: 'center',
      marginTop: 44,
      flexWrap: 'wrap'
    }
  }, REVIEWS.map(r => /*#__PURE__*/React.createElement(ReviewCard, _extends({
    key: r.author
  }, r, {
    rating: 5
  }))))), /*#__PURE__*/React.createElement(Section, null, /*#__PURE__*/React.createElement(SectionHeading, {
    title: "What we",
    accent: "offer"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 16,
      marginTop: 44
    }
  }, SERVICES.map(s => {
    const IconC = window.Icons[s.icon];
    return /*#__PURE__*/React.createElement("div", {
      key: s.key,
      style: {
        gridColumn: s.wide ? 'span 2' : 'span 1'
      }
    }, /*#__PURE__*/React.createElement(ServiceCard, {
      title: s.key,
      description: s.desc,
      wide: s.wide,
      icon: /*#__PURE__*/React.createElement(IconC, null),
      href: "#"
    }));
  }))), /*#__PURE__*/React.createElement(Section, null, /*#__PURE__*/React.createElement(GlassCard, {
    style: {
      padding: 0,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '48px 44px'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Global talent",
    title: "European management.",
    accent: "Vietnamese talent.",
    align: "left",
    size: "md"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-body)',
      fontSize: 16,
      lineHeight: 1.65,
      marginTop: 20,
      maxWidth: 440
    }
  }, "We bridge EU delivery standards with a deep Vietnamese engineering bench \u2014 so you get senior output, on your timezone overlap, at a sustainable cost."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: "soft"
  }, "\uD83C\uDDEA\uD83C\uDDFA EU Management"), /*#__PURE__*/React.createElement(Badge, {
    variant: "soft"
  }, "\uD83C\uDDFB\uD83C\uDDF3 Vietnam Delivery"))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      minHeight: 300,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'radial-gradient(circle at 50% 50%, rgba(86,117,254,0.18), transparent 70%)'
    }
  }, window.Icons.Globe({
    size: 180,
    stroke: 0.75,
    style: {
      color: 'rgba(255,255,255,0.35)'
    }
  }))))), /*#__PURE__*/React.createElement(Section, null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      borderRadius: 'var(--radius-xl)',
      border: '1px solid var(--border-glass)',
      background: 'rgba(255,255,255,0.02)',
      padding: '80px 32px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: -110,
      left: '50%',
      transform: 'translateX(-50%)',
      width: 280,
      height: 280,
      borderRadius: '50%',
      backgroundImage: 'var(--brand-gradient)',
      opacity: 0.25,
      filter: 'blur(120px)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 620,
      margin: '0 auto',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    title: "Let's build your",
    accent: "team.",
    size: "xl"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-body)',
      fontSize: 18,
      lineHeight: 1.6,
      maxWidth: 460,
      margin: 0
    }
  }, "Tell us what you're building. We'll line up the right engineers and a transparent plan."), /*#__PURE__*/React.createElement(ShimmerButton, {
    onClick: () => setRoute('Contact')
  }, "Book a call ", /*#__PURE__*/React.createElement("i", {
    style: {
      fontWeight: 700
    }
  }, "now"))))));
}
window.HomeScreen = HomeScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/PortfolioScreen.jsx
try { (() => {
// Portfolio: filterable bento grid of projects. Recreates the site's portfolio view
// (local data, domain filter chips, tech-stack tags).
const {
  Badge,
  GlassCard,
  SectionHeading
} = window.Ds8senecaDesignSystem_e04158;
const DOMAINS = ['All', 'Cybersecurity', 'e-Commerce', 'AI', 'Web3 & Blockchain', 'Enterprise', 'Public Services'];
const PROJECTS = [{
  title: 'Threat Intel Platform',
  domain: 'Cybersecurity',
  tech: ['Go', 'Kafka', 'React'],
  big: true
}, {
  title: 'Headless Storefront',
  domain: 'e-Commerce',
  tech: ['Next.js', 'Shopify']
}, {
  title: 'Document AI Pipeline',
  domain: 'AI',
  tech: ['Python', 'PyTorch']
}, {
  title: 'Custody Wallet',
  domain: 'Web3 & Blockchain',
  tech: ['Solidity', 'Rust']
}, {
  title: 'ERP Integration Layer',
  domain: 'Enterprise',
  tech: ['Java', 'SAP'],
  big: true
}, {
  title: 'Citizen Services Portal',
  domain: 'Public Services',
  tech: ['Vue', '.NET']
}, {
  title: 'Fraud Scoring Engine',
  domain: 'AI',
  tech: ['Python', 'XGBoost']
}, {
  title: 'SOC Dashboard',
  domain: 'Cybersecurity',
  tech: ['TypeScript', 'Elastic']
}];
function PortfolioScreen() {
  const [filter, setFilter] = React.useState('All');
  const shown = PROJECTS.filter(p => filter === 'All' || p.domain === filter);
  return /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      padding: '56px 32px 32px'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Selected work",
    title: "Delivery across",
    accent: "7 domains"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      flexWrap: 'wrap',
      justifyContent: 'center',
      margin: '36px 0 40px'
    }
  }, DOMAINS.map(d => {
    const active = d === filter;
    return /*#__PURE__*/React.createElement("button", {
      key: d,
      onClick: () => setFilter(d),
      style: {
        cursor: 'pointer',
        padding: '8px 18px',
        borderRadius: 9999,
        fontFamily: 'var(--font-body)',
        fontSize: 14,
        fontWeight: 600,
        border: '1px solid',
        borderColor: active ? 'transparent' : 'var(--border-glass)',
        backgroundImage: active ? 'var(--brand-gradient)' : 'none',
        background: active ? undefined : 'var(--surface-glass)',
        color: active ? '#fff' : 'var(--text-muted)',
        transition: 'all .3s'
      }
    }, d);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gridAutoRows: '208px',
      gap: 16
    }
  }, shown.map(p => /*#__PURE__*/React.createElement(GlassCard, {
    key: p.title,
    interactive: true,
    radius: "var(--radius-m)",
    style: {
      gridColumn: p.big ? 'span 2' : 'span 1',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      textTransform: 'uppercase',
      letterSpacing: '0.08em',
      color: 'var(--brand-blue)'
    }
  }, p.domain)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: p.big ? 28 : 20,
      fontWeight: 600,
      color: '#fff',
      margin: '0 0 14px'
    }
  }, p.title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, p.tech.map(t => /*#__PURE__*/React.createElement(Badge, {
    key: t,
    variant: "soft"
  }, t))))))));
}
window.PortfolioScreen = PortfolioScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/PortfolioScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Shell.jsx
try { (() => {
// Shell: fixed aurora backdrop, sticky header (logo, nav, language, CTA), and footer.
// Recreates the 8seneca marketing site chrome. Header nav drives the active route.
const {
  ShimmerButton
} = window.Ds8senecaDesignSystem_e04158;
const NAV = ['Home', 'Portfolio', 'Blog', 'Contact'];
function Header({
  route,
  setRoute
}) {
  const [scrolled, setScrolled] = React.useState(false);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 40,
      background: scrolled ? 'rgba(11,12,30,0.92)' : 'transparent',
      boxShadow: scrolled ? '0 8px 32px 0 rgba(0,0,0,0.35)' : 'none',
      transition: 'background .3s ease, box-shadow .3s ease'
    },
    onMouseEnter: () => setScrolled(true),
    onMouseLeave: () => setScrolled(false)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      padding: '16px 32px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-full-white.png",
    alt: "8seneca",
    style: {
      height: 26,
      cursor: 'pointer'
    },
    onClick: () => setRoute('Home')
  }), /*#__PURE__*/React.createElement("nav", {
    className: "nav-container",
    style: {
      display: 'flex',
      gap: 4
    }
  }, NAV.map(n => /*#__PURE__*/React.createElement("button", {
    key: n,
    onClick: () => setRoute(n),
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: '8px 16px',
      fontFamily: 'var(--font-body)',
      fontSize: 15,
      fontWeight: route === n ? 600 : 500,
      color: route === n ? '#fff' : 'rgba(255,255,255,0.7)',
      position: 'relative'
    }
  }, n, route === n && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      bottom: 2,
      left: 16,
      right: 16,
      height: 2,
      borderRadius: 2,
      background: 'linear-gradient(90deg,var(--brand-blue),var(--brand-red))',
      boxShadow: '0 0 12px 0 rgba(86,117,254,0.6)'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 13,
      color: 'rgba(255,255,255,0.6)',
      fontWeight: 600
    }
  }, "EN\xA0/\xA0", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'rgba(255,255,255,0.3)'
    }
  }, "DE")), /*#__PURE__*/React.createElement(ShimmerButton, {
    background: "#181e54",
    shimmerColor: "#5675fe",
    style: {
      padding: '10px 22px',
      fontSize: 14
    },
    onClick: () => setRoute('Contact')
  }, "Get in Touch"))));
}
function Footer({
  setRoute
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: '1px solid var(--border-glass)',
      marginTop: 80
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      padding: '56px 32px 40px',
      display: 'grid',
      gridTemplateColumns: '2fr 1fr 1fr',
      gap: 40
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-full-white.png",
    alt: "8seneca",
    style: {
      height: 26,
      marginBottom: 18
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      maxWidth: 320,
      color: 'var(--text-muted)',
      fontSize: 14,
      lineHeight: 1.6,
      margin: 0
    }
  }, "Pure Play B2B IT outsourcing. European management, elite Vietnamese talent."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/start-pilot.webp",
    alt: "Trustpilot",
    style: {
      height: 18
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 13
    }
  }, "\xB7"), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/clutch-logo.webp",
    alt: "Clutch",
    style: {
      height: 18
    }
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      textTransform: 'uppercase',
      letterSpacing: '0.15em',
      color: 'var(--text-faint)',
      fontWeight: 600,
      marginBottom: 14
    }
  }, "Company"), ['Home', 'Portfolio', 'Blog', 'Contact'].map(l => /*#__PURE__*/React.createElement("div", {
    key: l,
    onClick: () => setRoute(l),
    style: {
      color: 'var(--text-muted)',
      fontSize: 14,
      padding: '5px 0',
      cursor: 'pointer'
    }
  }, l))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      textTransform: 'uppercase',
      letterSpacing: '0.15em',
      color: 'var(--text-faint)',
      fontWeight: 600,
      marginBottom: 14
    }
  }, "Get in touch"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 14,
      padding: '5px 0'
    }
  }, "hello@8seneca.com"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 14,
      padding: '5px 0'
    }
  }, "Hanoi \xB7 Vietnam"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 14,
      padding: '5px 0'
    }
  }, "Prague \xB7 EU"))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border-glass)',
      padding: '20px 32px',
      textAlign: 'center',
      color: 'var(--text-faint)',
      fontSize: 12
    }
  }, "\xA9 2026 8seneca. All rights reserved."));
}
function Shell({
  route,
  setRoute,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": true,
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: -1,
      backgroundImage: 'var(--aurora)',
      backgroundRepeat: 'no-repeat',
      backgroundSize: '140% 140%,140% 140%,160% 160%,100% 100%',
      backgroundPosition: '18% 22%,82% 28%,50% 90%,0 0'
    }
  }), /*#__PURE__*/React.createElement(Header, {
    route: route,
    setRoute: setRoute
  }), /*#__PURE__*/React.createElement("main", null, children), /*#__PURE__*/React.createElement(Footer, {
    setRoute: setRoute
  }));
}
Object.assign(window, {
  Header,
  Footer,
  Shell,
  NAV
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/icons.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Lucide-style icon set used across the 8seneca site (Code2, ShieldCheck, Users, PenTool,
// Megaphone, ArrowRight, Globe, Menu, X, Check). Accurate copies of the lucide glyphs the
// codebase imports from lucide-react. Exposed on window for the babel scripts.
const Icon = ({
  paths,
  size = 24,
  stroke = 2,
  style = {},
  ...rest
}) => /*#__PURE__*/React.createElement("svg", _extends({
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: stroke,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  style: style
}, rest), paths);
const Icons = {
  Code: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    paths: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("polyline", {
      points: "16 18 22 12 16 6"
    }), /*#__PURE__*/React.createElement("polyline", {
      points: "8 6 2 12 8 18"
    }))
  })),
  Shield: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    paths: /*#__PURE__*/React.createElement("path", {
      d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"
    })
  })),
  Users: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    paths: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
      d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "9",
      cy: "7",
      r: "4"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M22 21v-2a4 4 0 0 0-3-3.87"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M16 3.13a4 4 0 0 1 0 7.75"
    }))
  })),
  Pen: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    paths: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
      d: "M12 19l7-7 3 3-7 7-3-3z"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M2 2l7.586 7.586"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "11",
      cy: "11",
      r: "2"
    }))
  })),
  Megaphone: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    paths: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
      d: "M3 11l18-5v12L3 14v-3z"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M11.6 16.8a3 3 0 1 1-5.8-1.6"
    }))
  })),
  Arrow: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    paths: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("line", {
      x1: "5",
      y1: "12",
      x2: "19",
      y2: "12"
    }), /*#__PURE__*/React.createElement("polyline", {
      points: "12 5 19 12 12 19"
    }))
  })),
  Globe: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    paths: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "10"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "2",
      y1: "12",
      x2: "22",
      y2: "12"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"
    }))
  })),
  Menu: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    paths: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("line", {
      x1: "3",
      y1: "6",
      x2: "21",
      y2: "6"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "3",
      y1: "12",
      x2: "21",
      y2: "12"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "3",
      y1: "18",
      x2: "21",
      y2: "18"
    }))
  })),
  X: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    paths: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("line", {
      x1: "18",
      y1: "6",
      x2: "6",
      y2: "18"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "6",
      y1: "6",
      x2: "18",
      y2: "18"
    }))
  })),
  Check: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    paths: /*#__PURE__*/React.createElement("polyline", {
      points: "20 6 9 17 4 12"
    })
  })),
  MapPin: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    paths: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
      d: "M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "10",
      r: "3"
    }))
  }))
};
window.Icons = Icons;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/icons.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.GlassCard = __ds_scope.GlassCard;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

__ds_ns.ShimmerButton = __ds_scope.ShimmerButton;

__ds_ns.ReviewCard = __ds_scope.ReviewCard;

__ds_ns.ServiceCard = __ds_scope.ServiceCard;

__ds_ns.StatTicker = __ds_scope.StatTicker;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Textarea = __ds_scope.Textarea;

})();
