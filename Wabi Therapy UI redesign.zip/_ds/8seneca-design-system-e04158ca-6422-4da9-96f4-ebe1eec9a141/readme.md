# 8seneca Design System

A brand + UI design system for **8seneca** — a **Pure Play B2B IT outsourcing / team-extension** company. European management, elite Vietnamese talent, one focus: B2B IT outsourcing that ships. Services span Cybersecurity, Software Development, IT Outsourcing, Design, and Marketing; engagement models are Talent Hiring, Custom Projects, and Team Hiring.

This system captures the current marketing-site redesign: a **dark, motion-forward, bento-driven** identity built on a signature blue→red gradient over a near-black base, with frosted-glass surfaces.

## Sources

Everything here was reverse-engineered from real 8seneca material — not invented:

- **Codebase (ground truth):** `8seneca-website/` — Next.js 15 App Router + React 19 + Tailwind v3 + framer-motion, bilingual (EN/DE). Design tokens lifted verbatim from `src/app/[locale]/globals.css` and `tailwind.config.js`. Fonts from `src/constants/font.ts`. Components referenced from `src/components/**` and `src/features/**`.
- **Design spec:** `8seneca-website/docs/superpowers/specs/2026-06-02-8seneca-redesign-design.md` ("Bold Bento, max motion").
- **Brand assets (uploads):** the color logo (`8seneca-01.png` → `assets/logo-color.png`), the repeating infinity-mark pattern (`Pattern-01.jpg`, `Pattern-02.jpg`), and a company folder/brochure PDF.
- **Copy:** `8seneca-website/translations/en.json` (voice + real product strings).

## Index / manifest

- `styles.css` — global entry point (import-only). Link this one file.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css` (spacing + radii + effects + motion), `fonts.css` (Google webfonts).
- `components/` — reusable React primitives, grouped:
  - `core/` — **Button**, **ShimmerButton**, **Badge**, **GlassCard**, **SectionHeading**
  - `forms/` — **Input**, **Textarea**, **Checkbox**
  - `data/` — **StatTicker**, **ServiceCard**, **ReviewCard**
- `ui_kits/website/` — interactive recreation of the marketing site (Home · Portfolio · Blog · Contact).
- `guidelines/` — foundation specimen cards (colors, type, spacing, brand).
- `assets/` — logos, brand pattern, partner logos, icon.
- `SKILL.md` — Agent-Skills-compatible entry for downloadable use.

Namespace for `@dsCard`/kit HTML: `window.Ds8senecaDesignSystem_e04158`.

## Components at a glance

Button, ShimmerButton, Badge, GlassCard, SectionHeading, Input, Textarea, Checkbox, StatTicker, ServiceCard, ReviewCard. See each component's `.prompt.md` for usage. The inventory mirrors what the site actually defines (glass buttons, custom checkbox, glass inputs, bento service tiles, count-up stats, testimonial cards) rather than a generic kit.

### Intentional additions
- **SectionHeading** and **StatTicker** are extracted as named primitives because the site repeats these exact patterns (eyebrow + gradient-accent title; count-up stat with gradient "+") across many sections, even though the codebase inlines them.

---

## CONTENT FUNDAMENTALS

**Voice:** confident, concise, technical-but-plain. Short declarative sentences and fragments used for rhythm — e.g. "Dedicated teams. Seamless execution." and "Adaptive architecture. Uncompromising protection." Punchy over corporate.

**Person:** "we"/"our" for 8seneca; "you"/"your" for the client ("Scale your engineering team", "Tell us what you're building"). Rarely "I".

**Signature move — the italic accent tail:** headlines lead with a plain clause, then land on a short italic, gradient-clipped phrase: "Scale your engineering team, *without the overhead.*" / "Let's build your *team.*" / "Trusted delivery, *by the numbers*". Keep the accent to 1–3 words.

**Casing:** Sentence case for headings and body. Eyebrows are UPPERCASE with wide tracking ("PURE PLAY · B2B IT OUTSOURCING"). Title Case only for nav/labels ("Talent Hiring", "Get in Touch").

**Emphasis:** bold inline for key nouns ("**European** management, elite **Vietnamese** talent"); occasional underline on a single adverb for wit ("that _actually_ ships").

**Emoji:** essentially none in product copy. Two country flags (🇪🇺 🇻🇳) appear as data labels on the global-talent section — treat as the only sanctioned emoji, and only there.

**Numbers:** confident and specific — "24+ projects", "7 domains", "5 services", "EU-managed". Stats animate up; a gradient "+" suffix.

**Tone examples (verbatim):**
- Hero: "European management, elite Vietnamese talent. One focus: B2B IT outsourcing that actually ships."
- Pure Play: "A Pure Play company focuses on one service and one goal… We don't try to do everything—just the IT services that matter most to you."
- CTA: "Tell us what you're building. We'll line up the right engineers and a transparent plan."

---

## VISUAL FOUNDATIONS

**Overall vibe:** dark, premium, techy, motion-forward. A near-black base washed by a slowly drifting aurora (blue / red / indigo blobs). Content sits on frosted-glass panels. The one signature is the **blue→red gradient**.

**Color:** two brand anchors only — blue `#5675fe` (dark `#181e54`) and red `#fd364f` — over base `#0b0c1e`. The `--brand-gradient` (`linear-gradient(135deg, blue 0%, blue 45%, red 100%)`) is the single source of truth for every accent: CTA fills, heading accent words, stat "+", rules, glows. Full 50–950 primary (blue), secondary (red), and cool-neutral scales exist but the dark UI mostly uses white-alpha tints, not the neutral greys. Max 1–2 background colors per surface.

**Type:** **Space Grotesk** for display (geometric, weights 500–700 — headings, stats, section titles) + **Inter** for body/UI (300–700). Headings are bold, tight tracking (`-0.02em`), large and fluid (`clamp()`). Eyebrows: 11px, uppercase, `0.25em` tracking, with a short gradient rule. Both are Google Fonts (exact match to the site's `next/font/google` usage) loaded via `tokens/fonts.css`.

**Backgrounds:** the fixed full-bleed **aurora** (`--aurora`) behind everything; radial-gradient blob glows behind CTAs; the repeating **infinity-mark pattern** (`assets/pattern-01.jpg`) for brand fills. No stock photography in the core marketing flow — imagery is the brand mark, partner logos, and abstract gradient/particle atmospheres. Cool color temperature (blues/indigos) warmed by the red tail.

**Surfaces / cards:** the ubiquitous glass panel — `background: rgba(255,255,255,0.05)`, `border: 1px solid rgba(255,255,255,0.10)`, `backdrop-filter: blur(12px)`, offset shadow `-5px 4px 4px rgba(0,0,0,0.25)`. Radii: inputs/buttons 4–6px, cards/bento 12px, large panels 16px, hero/CTA bands 24px, pills 9999px.

**Shadows / glows:** subtle black offset shadow on cards; **brand-blue glow** (`0 6px 22px -4px rgba(86,117,254,0.55)`, intensifying on hover) on primary buttons and pipeline nodes; a soft white halo on blog cards; inset top-glow on some bento tiles.

**Borders:** hairline white-alpha (`white/10`), strengthening to `white/25` on inputs/controls and warming to `blue/40` on hover for interactive cards.

**Transparency & blur:** used constantly — glass fills are `white/5`→`white/10`, backdrop-blur 12px on cards, inputs, the scrolled header bar, and pill chips. The scrolled header uses a semi-opaque dark fill (no backdrop-filter there, deliberately, to keep the mobile drawer's fixed positioning intact).

**Motion:** framer-motion + Magic UI. Blur-fade section reveals (staggered `delay`), count-up number tickers, marquees (tech stack / reviews), a rotating shimmer border on the primary CTA, particles/orbiting circles, an animated aurora drift (26s). Easing is smooth ease-out (`cubic-bezier(0.16,1,0.3,1)`); durations 0.2–0.5s for UI, longer for ambient. All heavy motion is gated behind `prefers-reduced-motion`.

**Hover states:** cards lift (`translateY(-4px)`) + border warms to blue + fill brightens; buttons deepen their glow; links slide their trailing arrow right and shift to blue; nav links reveal a gradient underline. **Press:** primary/shimmer buttons nudge down 1px (`translateY(1px)`).

**Layout:** centered max-width 1200px content column with 32px gutters; generous vertical rhythm (~64px section padding); asymmetric bento grids (2-col feature cells beside 1-col tiles). Full-bleed breakouts for marquees. Left-aligned hero, centered section headings.

---

## ICONOGRAPHY

- **System:** the site uses **lucide-react** (plus a few `@radix-ui/react-icons`), stroke-based, `strokeWidth` 1.5–2, 24px default. Icons are line icons, never filled, tinted white or white-alpha, warming to brand blue on hover. Service tiles use an **oversized watermark icon** (150–220px, ~5% white opacity) bleeding off the bottom-right corner as decoration.
- **In this system:** consumers should link **Lucide** from CDN (`https://unpkg.com/lucide@latest`) — the exact set the brand uses. For the offline UI-kit recreation, `ui_kits/website/icons.jsx` re-draws the specific lucide glyphs the site imports (Code, Shield, Users, Pen, Megaphone, Arrow, Globe, Menu, X, Check, MapPin) as accurate React SVGs so the kit needs no network. Prefer real Lucide in production.
- **Brand marks / assets copied in:** `assets/logo-color.png` (full color lockup on light), `assets/logo-full-white.png` (white lockup for dark), `assets/mark-white.png` (the "8" infinity mark), `assets/logo-white.webp` (webp lockup), `assets/icons/arrow-right.svg`, `assets/pattern-01.jpg` + `pattern-02.jpg` (repeating infinity pattern), partner logos `clutch-logo.webp` / `clutch-io.webp` / `trust-pilot.webp` / `start-pilot.webp`, and `avatar.webp`.
- **Emoji as icons:** only the two country flags on the global-talent labels (see Content Fundamentals). No other emoji.
- **Unicode glyphs:** used sparingly for separators (·) in eyebrows and lockups.

## Caveats / substitutions

- **Fonts:** Space Grotesk + Inter are loaded from Google Fonts. These are the exact families the site uses via `next/font/google`, so this is an exact match, not a substitution. No local font binaries were provided or needed.
- **Logo:** real 8seneca logo assets were provided and copied in — no mark was drawn or reconstructed.
- **Portfolio / blog content** in the UI kit is representative placeholder text in the brand voice (the live site pulls projects from local data and blog from WordPress); structure and styling are faithful, specific copy is illustrative.
